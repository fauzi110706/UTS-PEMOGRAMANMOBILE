
import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
} from "react-native";

export default function ProfileScreen() {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
    >
      <Text style={styles.headerTitle}>Profile</Text>

      <Text style={styles.headerSubtitle}>
        Informasi profil mahasiswa
      </Text>

      <View style={styles.profileCard}>
        <Image
          source={require("../assets/image.png")}
          style={styles.avatar}
          resizeMode="cover"
        />

        <Text style={styles.nameText}>
           Muhammad Fauzi
        </Text>

        <View style={styles.infoBox}>
          <Text style={styles.infoLabel}>NIM</Text>
          <Text style={styles.infoValue}>
            4112755201250060
          </Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.infoLabel}>
            Program Studi
          </Text>
          <Text style={styles.infoValue}>
            S1 Informatika
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F0F3FA",
  },
  content: {
    paddingHorizontal: 22,
    paddingTop: 35,
    paddingBottom: 30,
    flexGrow: 1,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#202124",
  },
  headerSubtitle: {
    fontSize: 15,
    color: "#6B7280",
    marginTop: 7,
    marginBottom: 25,
  },
  profileCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 22,
    padding: 25,
    alignItems: "center",
    elevation: 3,
  },
  avatar: {
    width: 110,
    height: 110,
    borderRadius: 55,
    borderWidth: 3,
    borderColor: "#2563EB",
    marginBottom: 18,
  },
  nameText: {
    fontSize: 21,
    fontWeight: "bold",
    color: "#111827",
    marginBottom: 25,
  },
  infoBox: {
    width: "100%",
    backgroundColor: "#F3F4F6",
    borderRadius: 12,
    paddingVertical: 13,
    paddingHorizontal: 16,
    marginBottom: 14,
  },
  infoLabel: {
    fontSize: 13,
    color: "#6B7280",
    marginBottom: 5,
  },
  infoValue: {
    fontSize: 15,
    fontWeight: "600",
    color: "#111827",
  },
});
