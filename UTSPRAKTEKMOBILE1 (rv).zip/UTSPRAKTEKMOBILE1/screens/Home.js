
import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ScrollView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function HomeScreen({
  navigation,
  user = "USER",
}) {
  const menus = [
    {
      id: "1",
      title: "Kalender",
      icon: "calendar-outline",
    },
    {
      id: "2",
      title: "Pembayaran",
      icon: "card-outline",
    },
    {
      id: "3",
      title: "Pendaftaran",
      icon: "create-outline",
    },
    {
      id: "4",
      title: "Pengumuman",
      icon: "megaphone-outline",
    },
  ];

  const handleMenuPress = (title) => {
    Alert.alert(
      "Menu Utama",
      `Kamu memilih ${title}.`
    );
  };

  const handleSettings = () => {
    Alert.alert(
      "Pengaturan",
      "Menu pengaturan dipilih."
    );
  };

  const handleLogout = () => {
    Alert.alert(
      "Konfirmasi Logout",
      "Apakah kamu yakin ingin keluar dari aplikasi?",
      [
        {
          text: "Batal",
          style: "cancel",
        },
        {
          text: "Logout",
          style: "destructive",
          onPress: () => {
            const rootNavigation = navigation.getParent();

            if (rootNavigation) {
              rootNavigation.replace("Login");
            } else {
              navigation.replace("Login");
            }
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Home</Text>

        <TouchableOpacity
          style={styles.settingsButton}
          activeOpacity={0.8}
          onPress={handleSettings}
        >
          <Ionicons
            name="settings"
            size={30}
            color="#FFFFFF"
          />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.welcomeCard}>
          <Text style={styles.welcomeSmall}>
            Selamat Datang 👋
          </Text>

          <Text style={styles.welcomeName}>
            {user}
          </Text>

          <Text style={styles.welcomeDescription}>
            Selamat datang di aplikasi mahasiswa
          </Text>
        </View>

        <Text style={styles.sectionTitle}>
          Menu Utama
        </Text>

        <View style={styles.menuGrid}>
          {menus.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={styles.menuCard}
              activeOpacity={0.75}
              onPress={() => handleMenuPress(item.title)}
            >
              <View style={styles.iconContainer}>
                <Ionicons
                  name={item.icon}
                  size={34}
                  color="#2563EB"
                />
              </View>

              <Text style={styles.menuText}>
                {item.title}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={styles.logoutButton}
          activeOpacity={0.8}
          onPress={handleLogout}
        >
          <Ionicons
            name="log-out-outline"
            size={22}
            color="#FFFFFF"
          />

          <Text style={styles.logoutText}>
            LOGOUT
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F0F3FA",
  },
  header: {
    minHeight: 78,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 28,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    elevation: 3,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#202124",
  },
  settingsButton: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: "#BDBDBD",
    alignItems: "center",
    justifyContent: "center",
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 30,
    paddingBottom: 30,
    flexGrow: 1,
  },
  welcomeCard: {
    backgroundColor: "#2864E8",
    borderRadius: 28,
    paddingHorizontal: 25,
    paddingVertical: 30,
    minHeight: 220,
    justifyContent: "center",
    marginBottom: 38,
  },
  welcomeSmall: {
    color: "#FFFFFF",
    fontSize: 19,
    marginBottom: 15,
  },
  welcomeName: {
    color: "#FFFFFF",
    fontSize: 27,
    fontWeight: "bold",
    marginBottom: 16,
  },
  welcomeDescription: {
    color: "#E7EEFF",
    fontSize: 16,
    lineHeight: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#202B3C",
    marginBottom: 22,
  },
  menuGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  menuCard: {
    width: "48%",
    minHeight: 155,
    backgroundColor: "#FFFFFF",
    borderRadius: 25,
    marginBottom: 20,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 8,
    paddingVertical: 20,
    elevation: 3,
    shadowColor: "#000000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
  },
  iconContainer: {
    marginBottom: 15,
  },
  menuText: {
    color: "#334155",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
  },
  logoutButton: {
    backgroundColor: "#EF4444",
    height: 52,
    borderRadius: 12,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 8,
    marginBottom: 12,
  },
  logoutText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "bold",
    marginLeft: 9,
  },
});
