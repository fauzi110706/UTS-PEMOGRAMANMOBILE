
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from "react-native";

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert(
        "Pemberitahuan",
        "Silakan masukkan email dan password."
      );
      return;
    }

    const displayName = email.trim().split("@")[0];

    navigation.replace("MainTabs", {
      user: displayName,
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        style={styles.keyboard}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.content}>
          <Text style={styles.title}>Halaman Login</Text>

          {/* <TextInput
            style={[styles.input, styles.nameInput]}
            placeholder="Username"
            placeholderTextColor="#222222"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            autoCorrect={false}
          /> */}

          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#222222"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            autoCorrect={false}
          />

          <TextInput
            style={[styles.input, styles.passwordInput]}
            placeholder="Password"
            placeholderTextColor="#222222"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoCapitalize="none"
          />

          <TouchableOpacity
            style={styles.loginButton}
            activeOpacity={0.8}
            onPress={handleLogin}
          >
            <Text style={styles.buttonText}>CLICK ME</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  keyboard: {
    flex: 1,
    justifyContent: "center",
  },
  content: {
    alignItems: "center",
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 34,
    color: "#0000FF",
    fontWeight: "400",
    marginBottom: 18,
    textAlign: "center",
  },
  input: {
    backgroundColor: "#FFFF00",
    minHeight: 64,
    borderRadius: 22,
    paddingHorizontal: 18,
    paddingVertical: 12,
    fontSize: 17,
    color: "#000000",
    textAlign: "center",
    marginBottom: 16,
    width: "100%",
    maxWidth: 370,
  },
  nameInput: {
    width: 150,
  },
  passwordInput: {
    width: 165,
    marginBottom: 10,
  },
  loginButton: {
    backgroundColor: "#2196F3",
    paddingHorizontal: 20,
    height: 52,
    borderRadius: 5,
    justifyContent: "center",
    alignItems: "center",
    elevation: 4,
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 17,
    fontWeight: "bold",
  },
});
